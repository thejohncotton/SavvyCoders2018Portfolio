export { default as Blog } from "./Blog";
export { default as Contact } from "./Contact";
export { default as Home } from "./Home";
export { default as Projects } from "./Projects";