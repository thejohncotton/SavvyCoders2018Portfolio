export default {
    body: "Contact",
    title: "Welcome to my Contact Page!",
    links: [`home`,`projects`,`blog`,`contact`]
    }