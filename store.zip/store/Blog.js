export default {
    body: "Blog",
    title: "Welcome to my blog!",
    links: [`home`,`projects`,`blog`,`contact`],
    // content: Blog()

    }