export default {
    body: "Projects",
    title: "Welcome to my projects page!",
    links: [`home`,`projects`,`blog`,`contact`],
}