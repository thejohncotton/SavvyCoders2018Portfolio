export default {
        body: "Home",
        title: "Welcome to John's Savvy Coders Portfolio",
        links: [`home`,`projects`,`blog`,`contact`]
    
}